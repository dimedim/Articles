package mymongo

import (
	"context"
	"redditclone/internal/entities"

	"go.mongodb.org/mongo-driver/mongo"
)

// type CommentsMongo interface {
// 	AddComment(ctx context.Context, com *entities.CommentM) error
// 	DeleteComment(ctx context.Context, commentID string) error
// }

// type PostsMongo interface {
// }

type MongoALLRepo interface {
	GetAllPosts(ctx context.Context) ([]*entities.PostMongo, error)
	CreatePost(ctx context.Context, post *entities.PostMongo) error
	GetPostsByCategory(ctx context.Context, category string) ([]*entities.PostMongo, error)
	GetPostByID(ctx context.Context, postID string) (*entities.PostMongo, error)
	GetUsersPosts(ctx context.Context, username string) ([]*entities.PostMongo, error)
	DeletePost(ctx context.Context, postID string) error

	AddComment(ctx context.Context, com *entities.CommentM) (*entities.PostMongo, error)
	DeleteComment(ctx context.Context, postID, commentID string) (*entities.PostMongo, error)

	ChangeVote(ctx context.Context, postID string, vote *entities.VoteM) (*entities.PostMongo, error)
	UnVote(ctx context.Context, postID, userID string) (*entities.PostMongo, error)
}

type ModgoDB struct {
	PostColl *mongo.Collection
	CommColl *mongo.Collection
}

func NewModgoDB(client *mongo.Client) *ModgoDB {
	return &ModgoDB{
		PostColl: client.Database("coursera").Collection("posts"),
		CommColl: client.Database("coursera").Collection("comments"),
	}
}
