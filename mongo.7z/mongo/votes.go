package mymongo

import (
	"context"
	"fmt"
	"redditclone/internal/entities"
	"redditclone/pkg/helpers"
	"slices"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
)

func (r *ModgoDB) ChangeVote(ctx context.Context, postID string, vote *entities.VoteM) (*entities.PostMongo, error) {
	id, err := primitive.ObjectIDFromHex(postID)
	if err != nil {
		return nil, fmt.Errorf("invalid postID: %w", err)
	}

	var pm entities.PostMongo
	if err := r.PostColl.FindOne(ctx, bson.M{"_id": id}).Decode(&pm); err != nil {
		if err == mongo.ErrNoDocuments {
			return nil, fmt.Errorf("post %s not found", postID)
		}
		return nil, fmt.Errorf("find post: %w", err)
	}

	found := false
	for i, v := range pm.Votes {
		if v.UserID == vote.UserID {
			pm.Score -= v.Vote
			pm.Votes[i].Vote = vote.Vote
			found = true
			break
		}
	}
	if !found {
		pm.Votes = append(pm.Votes, &entities.VoteM{
			UserID: vote.UserID,
			Vote:   vote.Vote,
		})
	}
	pm.Score += vote.Vote
	pm.UpvotePercentage = helpers.CalculateUpvotePercentage(pm.Votes)

	update := bson.M{"$set": bson.M{
		"votes":            pm.Votes,
		"score":            pm.Score,
		"upvotePercentage": pm.UpvotePercentage,
	}}

	if _, err := r.PostColl.UpdateOne(ctx, bson.M{"_id": id}, update); err != nil {
		return nil, fmt.Errorf("update vote: %w", err)
	}

	return &pm, nil

}

func (r *ModgoDB) UnVote(ctx context.Context, postID, userID string) (*entities.PostMongo, error) {
	id, err := primitive.ObjectIDFromHex(postID)
	if err != nil {
		return nil, fmt.Errorf("invalid postID: %w", err)
	}

	var pm entities.PostMongo
	if err := r.PostColl.FindOne(ctx, bson.M{"_id": id}).Decode(&pm); err != nil {
		if err == mongo.ErrNoDocuments {
			return nil, fmt.Errorf("post %s not found", postID)
		}
		return nil, fmt.Errorf("find post: %w", err)
	}

	for i, v := range pm.Votes {
		if v.UserID == userID {
			pm.Score -= v.Vote
			pm.Votes = slices.Delete(pm.Votes, i, i+1)
			break
		}
	}
	pm.UpvotePercentage = helpers.CalculateUpvotePercentage(pm.Votes)

	update := bson.M{"$set": bson.M{
		"votes":            pm.Votes,
		"score":            pm.Score,
		"upvotePercentage": pm.UpvotePercentage,
	}}
	if _, err := r.PostColl.UpdateOne(ctx, bson.M{"_id": id}, update); err != nil {
		return nil, fmt.Errorf("update unvote: %w", err)
	}

	return &pm, nil
}
