package mymongo

import (
	"context"
	"fmt"
	"redditclone/internal/entities"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
)

// type PostMongoRepo struct {
// 	PostColl *mongo.Collection
// 	CommColl CommentsMongo
// }

// func NewMongoPostRepo(client *mongo.Client, comm CommentsMongo) *PostMongoRepo {
// 	return &PostMongoRepo{
// 		PostColl: client.Database("golang").Collection("posts"),
// 		CommColl: comm,
// 	}
// }

// [MongoDB] posts.find(_id = postID) --> получаем пост
// [MongoDB] comments.find(post_id = postID) --> получаем все комментарии
// [MySQL] users.find(id = comment.author.id) --> получаем имя юзера
// [MySQL] users.find(id = post.author.id) --> получаем имя автора поста

// func (r *MongoPostRepo) GetAll(ctx context.Context) []*entities.PostMongo {

// }

// Сортировка, пропуск, лимит
// opts := options.Find().
//   SetSort(bson.D{{"createdAt", -1}}). // -1 — убывание
//   SetSkip(20).
//   SetLimit(10)

// cursor, _ := coll.Find(ctx, bson.D{}, opts)

func (r *ModgoDB) CreatePost(ctx context.Context, post *entities.PostMongo) error {
	_, err := r.PostColl.InsertOne(ctx, post)
	if err != nil {
		return fmt.Errorf("insert post: %w", err)
	}
	return nil
}

// TODO errors сейчас я просто возвращаю err сложно будет дебажить
func (r *ModgoDB) GetAllPosts(ctx context.Context) ([]*entities.PostMongo, error) {

	pipeline := mongo.Pipeline{
		{
			{Key: "$sort", Value: bson.D{
				{Key: "score", Value: -1},
			}},
		},
		{
			{Key: "$lookup", Value: bson.D{
				{Key: "from", Value: "comments"},
				{Key: "localField", Value: "_id"},
				{Key: "foreignField", Value: "post_id"},
				{Key: "as", Value: "comments"},
			}},
		},
	}
	cursor, err := r.PostColl.Aggregate(ctx, pipeline)
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	posts := []*entities.PostMongo{}
	if err := cursor.All(ctx, &posts); err != nil {
		return nil, err
	}
	return posts, nil
}

func (r *ModgoDB) GetPostByID(ctx context.Context, postID string) (
	*entities.PostMongo, error) {
	id, err := primitive.ObjectIDFromHex(postID)
	if err != nil {
		return nil, fmt.Errorf("invalid postID: %w", err)
	}
	_, err = r.PostColl.UpdateOne(
		ctx,
		bson.M{"_id": id},
		bson.M{"$inc": bson.M{"views": 1}},
	)
	if err != nil {
		return nil, fmt.Errorf("increment views: %w", err)
	}

	post := &entities.PostMongo{}

	if err = r.PostColl.FindOne(ctx, bson.M{"_id": id}).Decode(post); err != nil {
		return nil, err
	}

	comments, err := r.GetAllPostsComments(ctx, id)
	if err != nil {
		return nil, err
	}

	post.Comments = comments

	return post, nil

}

func (r *ModgoDB) GetPostsByCategory(ctx context.Context, category string) ([]*entities.PostMongo, error) {

	pipeline := mongo.Pipeline{
		{
			{Key: "$match", Value: bson.D{
				{Key: "category", Value: category},
			}},
		},
		{
			{Key: "$sort", Value: bson.D{
				{Key: "score", Value: -1},
			}},
		},
		{
			{Key: "$lookup", Value: bson.D{
				{Key: "from", Value: "comments"},
				{Key: "localField", Value: "_id"},
				{Key: "foreignField", Value: "post_id"},
				{Key: "as", Value: "comments"},
			}},
		},
	}

	cursor, err := r.PostColl.Aggregate(ctx, pipeline)
	if err != nil {
		return nil, fmt.Errorf("aggregate posts by category: %w", err)
	}
	defer cursor.Close(ctx)

	posts := []*entities.PostMongo{}
	if err := cursor.All(ctx, &posts); err != nil {
		return nil, fmt.Errorf("decode posts by category: %w", err)
	}

	return posts, nil
}

func (r *ModgoDB) DeletePost(ctx context.Context, postID string) error {
	id, err := primitive.ObjectIDFromHex(postID)
	if err != nil {
		return fmt.Errorf("invalid postID: %w", err)
	}

	if _, err = r.PostColl.DeleteOne(ctx, bson.M{"_id": id}); err != nil {
		return fmt.Errorf("delete one: %w", err)
	}

	return nil
}

func (r *ModgoDB) GetUsersPosts(ctx context.Context, username string) ([]*entities.PostMongo, error) {
	pipeline := mongo.Pipeline{
		{
			{Key: "$match", Value: bson.D{
				{Key: "author.username", Value: username},
			}},
		},
		{
			{Key: "$sort", Value: bson.D{
				{Key: "score", Value: -1},
			}},
		},
		{
			{Key: "$lookup", Value: bson.D{
				{Key: "from", Value: "comments"},
				{Key: "localField", Value: "_id"},
				{Key: "foreignField", Value: "post_id"},
				{Key: "as", Value: "comments"},
			}},
		},
	}
	cursor, err := r.PostColl.Aggregate(ctx, pipeline)
	if err != nil {
		return nil, fmt.Errorf("aggregate posts by username: %w", err)
	}
	defer cursor.Close(ctx)

	posts := []*entities.PostMongo{}
	if err := cursor.All(ctx, &posts); err != nil {
		return nil, fmt.Errorf("decode posts by username: %w", err)
	}

	return posts, nil
}

// func (r *ModgoDB) GetAllPosts(ctx context.Context) ([]*entities.PostMongo, error) {

// 	findOpts := options.Find().SetSort(bson.D{{Key: "score", Value: -1}})
// 	postCursor, err := r.PostColl.Find(ctx, bson.M{}, findOpts)
// 	if err != nil {
// 		return nil, err
// 	}
// 	defer postCursor.Close(ctx)

// 	posts := []*entities.PostMongo{}
// 	if err = postCursor.All(ctx, &posts); err != nil {
// 		return nil, err
// 	}

// 	comments, err := r.GetAllComments(ctx)
// 	if err != nil {
// 		return nil, err
// 	}

// 	commMap := make(map[primitive.ObjectID][]*entities.CommentM, len(comments))

// 	for _, post := range posts {
// 		post.Comments = commMap[post.ID]
// 	}
// 	return posts, nil
// }
