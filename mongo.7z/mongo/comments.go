package mymongo

import (
	"context"
	"fmt"
	"redditclone/internal/entities"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// type CommentsMongoRepo struct {
// 	CommentsCollection *mongo.Collection
// }

// func NewCommentsMongoRepo(client *mongo.Client) *CommentsMongoRepo {
// 	return &CommentsMongoRepo{
// 		CommentsCollection: client.Database("golang").Collection("comments"),
// 	}
// }

func (r *ModgoDB) AddComment(ctx context.Context, com *entities.CommentM) (*entities.PostMongo, error) {
	_, err := r.CommColl.InsertOne(ctx, com)
	if err != nil {
		return nil, fmt.Errorf("insert comment: %w", err)
	}
	return r.GetPostByID(ctx, com.PostID.Hex())
}

func (r *ModgoDB) DeleteComment(ctx context.Context, postID, commentID string) (*entities.PostMongo, error) {
	id, err := primitive.ObjectIDFromHex(commentID)
	if err != nil {
		return nil, fmt.Errorf("invalid commentID: %w", err)
	}
	if _, err := r.CommColl.DeleteOne(ctx, bson.M{"_id": id}); err != nil {
		return nil, fmt.Errorf("delete comment: %w", err)
	}
	return r.GetPostByID(ctx, postID)
}

func (r *ModgoDB) GetAllPostsComments(ctx context.Context,
	postID primitive.ObjectID) ([]*entities.CommentM, error) {
	findOpts := options.Find().SetSort(bson.D{{Key: "created", Value: 1}})
	cursor, err := r.CommColl.Find(ctx, bson.M{"post_id": postID}, findOpts)
	if err != nil {
		return nil, fmt.Errorf("find comment: %w", err)
	}
	defer cursor.Close(ctx)

	comments := []*entities.CommentM{}
	if err = cursor.All(ctx, &comments); err != nil {
		return nil, fmt.Errorf("all comments: %w", err)
	}

	return comments, nil
}

// func (r *ModgoDB) GetAllComments(ctx context.Context) ([]*entities.CommentM, error) {
// 	commCursor, err := r.CommColl.Find(ctx, bson.M{}, nil)
// 	if err != nil {
// 		return nil, err
// 	}
// 	defer commCursor.Close(ctx)

// 	comments := []*entities.CommentM{}
// 	if err = commCursor.All(ctx, &comments); err != nil {
// 		return nil, err
// 	}

// 	return comments, nil
// }

func (r *ModgoDB) GetAllComments(ctx context.Context) ([]*entities.PostCommentsM, error) {
	commCursor, err := r.CommColl.Find(ctx, bson.M{}, nil)
	if err != nil {
		return nil, err
	}
	defer commCursor.Close(ctx)

	comments := []*entities.PostCommentsM{}
	if err = commCursor.All(ctx, &comments); err != nil {
		return nil, err
	}

	return comments, nil
}
